/* Imports for global scope */

Mongo = Package.mongo.Mongo;
ReactiveVar = Package['reactive-var'].ReactiveVar;
$ = Package.jquery.$;
jQuery = Package.jquery.jQuery;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
YT = Package['adrianliaw:youtube-iframe-api'].YT;
YTConfig = Package['adrianliaw:youtube-iframe-api'].YTConfig;
Meteor = Package.meteor.Meteor;
global = Package.meteor.global;
meteorEnv = Package.meteor.meteorEnv;
WebApp = Package.webapp.WebApp;
_ = Package.underscore._;
DDP = Package['ddp-client'].DDP;
FastClick = Package.fastclick.FastClick;
LaunchScreen = Package['launch-screen'].LaunchScreen;
Autoupdate = Package.autoupdate.Autoupdate;
Reload = Package.reload.Reload;
meteorInstall = Package.modules.meteorInstall;
Buffer = Package.modules.Buffer;
process = Package.modules.process;

