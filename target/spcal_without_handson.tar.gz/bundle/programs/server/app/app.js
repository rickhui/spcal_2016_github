var require = meteorInstall({"collections":{"dcdc.js":function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// collections/dcdc.js                                               //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
DcdcData = new Mongo.Collection("dcdc");                             // 1
                                                                     //
DcdcData.allow({                                                     // 3
  insert: function insert() {                                        // 4
    if (Meteor.isServer) {                                           // 5
      return true;                                                   // 6
    } else {                                                         //
      return false;                                                  // 8
    }                                                                //
  },                                                                 //
  update: function update() {                                        // 11
    if (Meteor.isServer) {                                           // 12
      return true;                                                   // 13
    } else {                                                         //
      return false;                                                  // 15
    }                                                                //
  },                                                                 //
  remove: function remove() {                                        // 18
    if (Meteor.isServer) {                                           // 19
      return true;                                                   // 20
    } else {                                                         //
      return false;                                                  // 22
    }                                                                //
  }                                                                  //
});                                                                  //
///////////////////////////////////////////////////////////////////////

}},"server":{"main.js":["meteor/meteor",function(require){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/main.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
var _meteorMeteor = require('meteor/meteor');                        //
                                                                     //
_meteorMeteor.Meteor.startup(function () {                           // 3
  // code to run on server at startup                                //
                                                                     //
  //Insert pricing data from dcdc                                    //
  var dcdcJson = JSON.parse(Assets.getText("dcdc.json"));            // 7
  dcdcJson.forEach(function (item) {                                 // 8
    var exists = DcdcData.findOne({ underlying: item.underlying, strike: item.strike, ko_type: item.ko_type, ko_barrier: item.ko_barrier, coupon_pa: item.coupon_pa, tenor: item.tenor, barrier_type: item.barrier_type, ki_barrier: item.ki_barrier });
    if (!exists) {                                                   // 10
      DcdcData.insert(item);                                         // 11
    }                                                                //
  });                                                                //
});                                                                  //
///////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".html"]});
require("./collections/dcdc.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
